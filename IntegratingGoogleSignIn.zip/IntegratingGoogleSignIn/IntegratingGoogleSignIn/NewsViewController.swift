//
//  NewsViewController.swift
//  IntegratingGoogleSignIn
//
//  Created by brn.developers on 11/15/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class NewsViewController: UIViewController {
    
    var image : String!

    override func viewDidLoad() {
        super.viewDidLoad()

        var imageView = UIImageView(frame: CGRect.init(x: 100, y: 250, width: 250, height: 350))
        view.addSubview(imageView)
        do {
            imageView.image  = try UIImage(data: Data(contentsOf: userDetails[0].image))
            
        }catch {
            print("No Image Found")
        }
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
