//
//  RecentNewsViewController.swift
//  IntegratingGoogleSignIn
//
//  Created by brn.developers on 11/15/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit
import GoogleSignIn


class RecentNewsViewController: UIViewController, XMLParserDelegate{
    
    var currentParsingElement:String = ""
    @IBOutlet weak var newsTableView: UITableView!
    var loginDataTask : URLSessionDataTask!
    var urlSessionObject : URLSession!
    var urlRequestObject : URLRequest!
    var xmlParseObj : XMLParser!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getXMLDataFromServer()
//        urlSessionObject = URLSession.shared
//        urlRequestObject = URLRequest(url:URL(string: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms")!)
//        if let userDataTask = loginDataTask{
//            loginDataTask = urlSessionObject.dataTask(with: urlRequestObject, completionHandler: { (data, resp, error) in
//                //print(data ?? <#default value#>)
//                self.xmlParseObj = XMLParser(data: data!)
//                self.xmlParseObj.delegate = self
//                self.xmlParseObj.parse()
//            })
//        }else
//        {
//            print("error")
//        }
        
//        loginDataTask = urlSessionObject.dataTask(with: urlRequestObject, completionHandler: { (data, resp, error) in
//            //print(data ?? <#default value#>)
//            self.xmlParseObj = XMLParser(data: data!)
//            self.xmlParseObj.delegate = self
//            self.xmlParseObj.parse()
//        })
//        //xmlParseObj = XMLParser(data: data!)
//        xmlParseObj.delegate = self
//        xmlParseObj.parse()
//        urlSessionObject.dataTask(with: urlRequestObject) { (data, response, error) in
//
//            print(data)
//            do {
//                let json = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
//                print(json)
//            }catch {
//                print(error.localizedDescription)
//            }
//
//        }.resume()
    }
    
    @IBAction func settingsAction(_ sender: UIBarButtonItem) {
        
        let nvc = self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController" ) as! SettingsViewController
        self.present(nvc, animated: true, completion: nil)
    }
    
    func getXMLDataFromServer(){
        let url = NSURL(string: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms")
        
        //Creating data task
        let task = URLSession.shared.dataTask(with: url! as URL) { (data, response, error) in
            print(data!)
            if data == nil {
                print("dataTaskWithRequest error: \(String(describing: error?.localizedDescription))")
                return
            }
            
            let parser = XMLParser(data: data!)
            parser.delegate = self
            parser.parse()
            
        }
        
        task.resume()
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if(elementName == "channel" || elementName == "title" || elementName == "description")
        {
            currentParsingElement = elementName
        }
    }
    

}
