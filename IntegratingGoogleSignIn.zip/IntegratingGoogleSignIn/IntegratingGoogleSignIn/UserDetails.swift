//
//  UserDetails.swift
//  IntegratingGoogleSignIn
//
//  Created by brn.developers on 11/15/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import Foundation

struct Profile {
    
    var name : String
    var email : String
    var image : URL
    
    init(username:String,mailid:String,userImage:URL) {
        self.name =  username
        self.email = mailid
        self.image = userImage
    }
}
