//
//  ViewController.swift
//  IntegratingGoogleSignIn
//
//  Created by brn.developers on 10/30/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit
import GoogleSignIn
import Kingfisher
var userDetails = [Profile]()
class ViewController: UIViewController,GIDSignInUIDelegate,GIDSignInDelegate {
    
    var imageView = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView = UIImageView(frame: CGRect.init(x: 50, y: 350, width: 300, height: 150))
        imageView.backgroundColor = UIColor.red
        view.addSubview(imageView)
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else if (GIDSignIn.sharedInstance()?.hasAuthInKeychain())! {
            
            let fullName = user.profile.name
            let email = user.profile.email
            
            let myImage =   user.profile.imageURL(withDimension: 100)
            
//            do {
//                imageView.image  = try UIImage(data: Data(contentsOf: myImage!))
//
//            }catch {
//                print("No Image Found")
//            }
            userDetails.append(Profile(username: fullName!, mailid: email!, userImage: myImage!))
            var nvc = self.storyboard?.instantiateViewController(withIdentifier: "RecentNewsViewController") as! RecentNewsViewController
            navigationController?.pushViewController(nvc, animated: true)
        }else {
            print("Unable to Login")
        }
    }
    
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
        print(error.localizedDescription)
    }
    
    
    
    @IBAction func googleSignInAction(_ sender: AnyObject) {
        
        GIDSignIn.sharedInstance().delegate=self
        GIDSignIn.sharedInstance().uiDelegate=self
        GIDSignIn.sharedInstance().signIn()
        
        
    }
    
    
    
}

