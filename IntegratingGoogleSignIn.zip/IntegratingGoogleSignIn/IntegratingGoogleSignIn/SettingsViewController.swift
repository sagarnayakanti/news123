//
//  SettingsViewController.swift
//  IntegratingGoogleSignIn
//
//  Created by brn.developers on 11/15/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        emailLabel.text = userDetails[0].email
        nameLabel.text = userDetails[0].name
        do {
            imageView.image  = try UIImage(data: Data(contentsOf: userDetails[0].image))
            
        }catch {
            print("No Image Found")
        }
    }
    
    @IBAction func hinduNewsPaper(_ sender: Any) {
        
    }
    
    @IBAction func timesNewsPaper(_ sender: Any) {
    }
    
    
    @IBAction func logoutAction(_ sender: Any) {
        
       
    }
    
    
}
